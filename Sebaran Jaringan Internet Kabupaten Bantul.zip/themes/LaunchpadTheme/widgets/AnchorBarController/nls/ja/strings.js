define({
  "_widgetLabel": "アンカー バー コントローラー",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_layout1": "レイアウト 0",
  "more": "その他のウィジェット"
});