define({
  "_widgetLabel": "Kontrolenhed for forankringslinje",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 0",
  "more": "Flere widgets"
});