define({
  "_widgetLabel": "Controlador de Barra Âncora",
  "_layout_default": "Layout padrão",
  "_layout_layout1": "Layout 0",
  "more": "Mais widgtes"
});