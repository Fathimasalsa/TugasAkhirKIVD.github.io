define({
  "_widgetLabel": "Kotroler trake sidra",
  "_layout_default": "Zadani izgled",
  "_layout_layout1": "Izgled 0",
  "more": "Više widgeta"
});