define({
  "_widgetLabel": "Enkura joslas kontrolieris",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_layout1": "0. izkārtojums",
  "more": "Vairāk logrīku"
});